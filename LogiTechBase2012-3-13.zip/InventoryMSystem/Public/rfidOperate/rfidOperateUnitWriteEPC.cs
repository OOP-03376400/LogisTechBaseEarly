﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InventoryMSystem.Public.rfidOperate
{
    class rfidOperateUnitWriteEPC
    {
    }
}
