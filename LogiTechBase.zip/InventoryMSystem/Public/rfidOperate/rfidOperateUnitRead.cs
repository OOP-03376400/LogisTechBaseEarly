﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InventoryMSystem
{
    public class rfidOperateUnitRead : rfidOperateUnitBase
    {
    }
}
