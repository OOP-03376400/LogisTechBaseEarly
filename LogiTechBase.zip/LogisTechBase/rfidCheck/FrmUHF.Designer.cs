﻿namespace LogisTechBase
{
    partial class FrmUHF
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmUHF));
            this.label1 = new System.Windows.Forms.Label();
            this.cmbPortName = new System.Windows.Forms.ComboBox();
            this.cmbBaudRate = new System.Windows.Forms.ComboBox();
            this.cmbStopBits = new System.Windows.Forms.ComboBox();
            this.cmbParity = new System.Windows.Forms.ComboBox();
            this.cmbDataBits = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_opencom = new System.Windows.Forms.Button();
            this.btn_closecom = new System.Windows.Forms.Button();
            this.txt_showinfo = new System.Windows.Forms.TextBox();
            this.txt_Send = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.checkBoxHexView = new System.Windows.Forms.CheckBox();
            this.checkBoxHexSend = new System.Windows.Forms.CheckBox();
            this.labelSendCount = new System.Windows.Forms.Label();
            this.btn_RtxtClear = new System.Windows.Forms.Button();
            this.ctrList = new System.Windows.Forms.ListView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmb_Qvalue = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.btn_start = new System.Windows.Forms.Button();
            this.cb_ = new System.Windows.Forms.CheckBox();
            this.lb_status = new System.Windows.Forms.ListBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btn_setfreq = new System.Windows.Forms.Button();
            this.btn_readfrq = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.chb_125FREBASE = new System.Windows.Forms.CheckBox();
            this.chb_50FREBASE = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.cb_FREMODE = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cb_dbm = new System.Windows.Forms.ComboBox();
            this.tb_dbm = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_setpower = new System.Windows.Forms.Button();
            this.btn_repower = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.单步命令 = new System.Windows.Forms.TabPage();
            this.btn_KillTag = new System.Windows.Forms.Button();
            this.txt_KillPsw = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.btn_lock = new System.Windows.Forms.Button();
            this.btn_lockpara = new System.Windows.Forms.Button();
            this.txt_lockpara = new System.Windows.Forms.TextBox();
            this.txt_accesspsw = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.btn_rerasedata = new System.Windows.Forms.Button();
            this.txt_datahex = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.ritedata = new System.Windows.Forms.Button();
            this.cb_RepeatWrite = new System.Windows.Forms.CheckBox();
            this.txt_datalen = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.btn_ReadData = new System.Windows.Forms.Button();
            this.cb_ReadRepeat = new System.Windows.Forms.CheckBox();
            this.txt_address = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.cb_safe = new System.Windows.Forms.CheckBox();
            this.cbx_bank = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.cB_uii = new System.Windows.Forms.CheckBox();
            this.txt_UII = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.单步命令.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "串口";
            // 
            // cmbPortName
            // 
            this.cmbPortName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPortName.FormattingEnabled = true;
            this.cmbPortName.Location = new System.Drawing.Point(41, 20);
            this.cmbPortName.Name = "cmbPortName";
            this.cmbPortName.Size = new System.Drawing.Size(71, 20);
            this.cmbPortName.TabIndex = 10;
            this.cmbPortName.SelectedIndexChanged += new System.EventHandler(this.cmbPortName_SelectedIndexChanged);
            // 
            // cmbBaudRate
            // 
            this.cmbBaudRate.FormattingEnabled = true;
            this.cmbBaudRate.Items.AddRange(new object[] {
            "300",
            "600",
            "1200",
            "2400",
            "4800",
            "9600",
            "14400",
            "28800",
            "36000",
            "57600",
            "115200"});
            this.cmbBaudRate.Location = new System.Drawing.Point(165, 20);
            this.cmbBaudRate.Name = "cmbBaudRate";
            this.cmbBaudRate.Size = new System.Drawing.Size(79, 20);
            this.cmbBaudRate.TabIndex = 11;
            this.cmbBaudRate.SelectedIndexChanged += new System.EventHandler(this.cmbBaudRate_SelectedIndexChanged);
            // 
            // cmbStopBits
            // 
            this.cmbStopBits.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbStopBits.FormattingEnabled = true;
            this.cmbStopBits.Items.AddRange(new object[] {
            "1",
            "2"});
            this.cmbStopBits.Location = new System.Drawing.Point(346, 77);
            this.cmbStopBits.Name = "cmbStopBits";
            this.cmbStopBits.Size = new System.Drawing.Size(88, 20);
            this.cmbStopBits.TabIndex = 14;
            this.cmbStopBits.Visible = false;
            // 
            // cmbParity
            // 
            this.cmbParity.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbParity.FormattingEnabled = true;
            this.cmbParity.Items.AddRange(new object[] {
            "None",
            "Even",
            "Odd"});
            this.cmbParity.Location = new System.Drawing.Point(346, 13);
            this.cmbParity.Name = "cmbParity";
            this.cmbParity.Size = new System.Drawing.Size(88, 20);
            this.cmbParity.TabIndex = 12;
            this.cmbParity.Visible = false;
            // 
            // cmbDataBits
            // 
            this.cmbDataBits.FormattingEnabled = true;
            this.cmbDataBits.Items.AddRange(new object[] {
            "7",
            "8",
            "9"});
            this.cmbDataBits.Location = new System.Drawing.Point(346, 48);
            this.cmbDataBits.Name = "cmbDataBits";
            this.cmbDataBits.Size = new System.Drawing.Size(88, 20);
            this.cmbDataBits.TabIndex = 13;
            this.cmbDataBits.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(118, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 15;
            this.label2.Text = "波特率";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(299, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 16;
            this.label3.Text = "校验位";
            this.label3.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(299, 51);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 17;
            this.label4.Text = "数据位";
            this.label4.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(299, 85);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 12);
            this.label5.TabIndex = 18;
            this.label5.Text = "停止位";
            this.label5.Visible = false;
            // 
            // btn_opencom
            // 
            this.btn_opencom.Location = new System.Drawing.Point(250, 17);
            this.btn_opencom.Name = "btn_opencom";
            this.btn_opencom.Size = new System.Drawing.Size(66, 23);
            this.btn_opencom.TabIndex = 19;
            this.btn_opencom.Text = "连接";
            this.btn_opencom.UseVisualStyleBackColor = true;
            this.btn_opencom.Click += new System.EventHandler(this.btn_opencom_Click);
            // 
            // btn_closecom
            // 
            this.btn_closecom.Location = new System.Drawing.Point(93, 72);
            this.btn_closecom.Name = "btn_closecom";
            this.btn_closecom.Size = new System.Drawing.Size(66, 23);
            this.btn_closecom.TabIndex = 20;
            this.btn_closecom.Text = "断开连接";
            this.btn_closecom.UseVisualStyleBackColor = true;
            this.btn_closecom.Visible = false;
            this.btn_closecom.Click += new System.EventHandler(this.btn_closecom_Click);
            // 
            // txt_showinfo
            // 
            this.txt_showinfo.Location = new System.Drawing.Point(152, 474);
            this.txt_showinfo.Multiline = true;
            this.txt_showinfo.Name = "txt_showinfo";
            this.txt_showinfo.Size = new System.Drawing.Size(302, 24);
            this.txt_showinfo.TabIndex = 21;
            this.txt_showinfo.Visible = false;
            this.txt_showinfo.TextChanged += new System.EventHandler(this.txt_showinfo_TextChanged);
            // 
            // txt_Send
            // 
            this.txt_Send.Location = new System.Drawing.Point(96, 469);
            this.txt_Send.Multiline = true;
            this.txt_Send.Name = "txt_Send";
            this.txt_Send.Size = new System.Drawing.Size(191, 40);
            this.txt_Send.TabIndex = 22;
            this.txt_Send.Visible = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(356, 489);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(66, 23);
            this.button1.TabIndex = 23;
            this.button1.Text = "手动发送";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(274, 19);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 24;
            this.button2.Text = "退出";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // checkBoxHexView
            // 
            this.checkBoxHexView.AutoSize = true;
            this.checkBoxHexView.Checked = true;
            this.checkBoxHexView.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxHexView.Location = new System.Drawing.Point(220, 474);
            this.checkBoxHexView.Name = "checkBoxHexView";
            this.checkBoxHexView.Size = new System.Drawing.Size(96, 16);
            this.checkBoxHexView.TabIndex = 25;
            this.checkBoxHexView.Text = "十六进制显示";
            this.checkBoxHexView.UseVisualStyleBackColor = true;
            this.checkBoxHexView.Visible = false;
            // 
            // checkBoxHexSend
            // 
            this.checkBoxHexSend.AutoSize = true;
            this.checkBoxHexSend.Location = new System.Drawing.Point(371, 467);
            this.checkBoxHexSend.Name = "checkBoxHexSend";
            this.checkBoxHexSend.Size = new System.Drawing.Size(96, 16);
            this.checkBoxHexSend.TabIndex = 26;
            this.checkBoxHexSend.Text = "十六进制发送";
            this.checkBoxHexSend.UseVisualStyleBackColor = true;
            this.checkBoxHexSend.Visible = false;
            // 
            // labelSendCount
            // 
            this.labelSendCount.AutoSize = true;
            this.labelSendCount.Location = new System.Drawing.Point(12, 486);
            this.labelSendCount.Name = "labelSendCount";
            this.labelSendCount.Size = new System.Drawing.Size(65, 12);
            this.labelSendCount.TabIndex = 27;
            this.labelSendCount.Text = "发送数据：";
            this.labelSendCount.Visible = false;
            // 
            // btn_RtxtClear
            // 
            this.btn_RtxtClear.Location = new System.Drawing.Point(37, 478);
            this.btn_RtxtClear.Name = "btn_RtxtClear";
            this.btn_RtxtClear.Size = new System.Drawing.Size(75, 23);
            this.btn_RtxtClear.TabIndex = 28;
            this.btn_RtxtClear.Text = "清空显示";
            this.btn_RtxtClear.UseVisualStyleBackColor = true;
            this.btn_RtxtClear.Visible = false;
            this.btn_RtxtClear.Click += new System.EventHandler(this.btn_RtxtClear_Click);
            // 
            // ctrList
            // 
            this.ctrList.Location = new System.Drawing.Point(4, 5);
            this.ctrList.MultiSelect = false;
            this.ctrList.Name = "ctrList";
            this.ctrList.Size = new System.Drawing.Size(450, 430);
            this.ctrList.TabIndex = 29;
            this.ctrList.UseCompatibleStateImageBehavior = false;
            this.ctrList.View = System.Windows.Forms.View.Details;
            this.ctrList.SelectedIndexChanged += new System.EventHandler(this.listView1_SelectedIndexChanged);
            this.ctrList.DoubleClick += new System.EventHandler(this.ctrList_DoubleClick);
            this.ctrList.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.ctrList_ColumnClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmb_Qvalue);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.checkBox2);
            this.groupBox1.Controls.Add(this.btn_start);
            this.groupBox1.Controls.Add(this.cb_);
            this.groupBox1.Controls.Add(this.cmbPortName);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cmbBaudRate);
            this.groupBox1.Controls.Add(this.btn_opencom);
            this.groupBox1.Controls.Add(this.btn_closecom);
            this.groupBox1.Location = new System.Drawing.Point(466, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(367, 92);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "基本操作";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // cmb_Qvalue
            // 
            this.cmb_Qvalue.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_Qvalue.FormattingEnabled = true;
            this.cmb_Qvalue.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16"});
            this.cmb_Qvalue.Location = new System.Drawing.Point(86, 50);
            this.cmb_Qvalue.Name = "cmb_Qvalue";
            this.cmb_Qvalue.Size = new System.Drawing.Size(157, 20);
            this.cmb_Qvalue.TabIndex = 34;
            this.cmb_Qvalue.SelectedIndexChanged += new System.EventHandler(this.cmb_Qvalue_SelectedIndexChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 57);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(77, 12);
            this.label25.TabIndex = 33;
            this.label25.Text = "防碰撞识别Q:";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(165, 71);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(78, 16);
            this.checkBox2.TabIndex = 32;
            this.checkBox2.Text = "checkBox2";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.Visible = false;
            // 
            // btn_start
            // 
            this.btn_start.Location = new System.Drawing.Point(250, 46);
            this.btn_start.Name = "btn_start";
            this.btn_start.Size = new System.Drawing.Size(66, 23);
            this.btn_start.TabIndex = 31;
            this.btn_start.Text = "识别标签";
            this.btn_start.UseVisualStyleBackColor = true;
            this.btn_start.Click += new System.EventHandler(this.btn_start_Click);
            // 
            // cb_
            // 
            this.cb_.AutoSize = true;
            this.cb_.Location = new System.Drawing.Point(41, 76);
            this.cb_.Name = "cb_";
            this.cb_.Size = new System.Drawing.Size(78, 16);
            this.cb_.TabIndex = 31;
            this.cb_.Text = "checkBox1";
            this.cb_.UseVisualStyleBackColor = true;
            this.cb_.Visible = false;
            // 
            // lb_status
            // 
            this.lb_status.FormattingEnabled = true;
            this.lb_status.ItemHeight = 12;
            this.lb_status.Location = new System.Drawing.Point(4, 443);
            this.lb_status.Name = "lb_status";
            this.lb_status.Size = new System.Drawing.Size(450, 76);
            this.lb_status.TabIndex = 31;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.单步命令);
            this.tabControl1.Location = new System.Drawing.Point(474, 111);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(359, 350);
            this.tabControl1.TabIndex = 32;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.cb_dbm);
            this.tabPage1.Controls.Add(this.tb_dbm);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.btn_setpower);
            this.tabPage1.Controls.Add(this.btn_repower);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(351, 324);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "UHF 模块参数设置";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btn_setfreq);
            this.groupBox2.Controls.Add(this.btn_readfrq);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.comboBox2);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.chb_125FREBASE);
            this.groupBox2.Controls.Add(this.chb_50FREBASE);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.cb_FREMODE);
            this.groupBox2.Controls.Add(this.textBox1);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Location = new System.Drawing.Point(8, 101);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(337, 217);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "频率设置";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // btn_setfreq
            // 
            this.btn_setfreq.Location = new System.Drawing.Point(256, 46);
            this.btn_setfreq.Name = "btn_setfreq";
            this.btn_setfreq.Size = new System.Drawing.Size(75, 23);
            this.btn_setfreq.TabIndex = 18;
            this.btn_setfreq.Text = "设置频率";
            this.btn_setfreq.UseVisualStyleBackColor = true;
            this.btn_setfreq.Visible = false;
            this.btn_setfreq.Click += new System.EventHandler(this.btn_setfreq_Click);
            // 
            // btn_readfrq
            // 
            this.btn_readfrq.Location = new System.Drawing.Point(256, 14);
            this.btn_readfrq.Name = "btn_readfrq";
            this.btn_readfrq.Size = new System.Drawing.Size(75, 23);
            this.btn_readfrq.TabIndex = 17;
            this.btn_readfrq.Text = "读取频率";
            this.btn_readfrq.UseVisualStyleBackColor = true;
            this.btn_readfrq.Click += new System.EventHandler(this.btn_readfrq_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(235, 180);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(23, 12);
            this.label17.TabIndex = 16;
            this.label17.Text = "KHz";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(167, 171);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(62, 21);
            this.textBox4.TabIndex = 15;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "中国标准920-925MHz",
            "中国标准840-845MHz",
            "ETSI标准",
            "定频模式915MHz",
            "用户自定义"});
            this.comboBox2.Location = new System.Drawing.Point(99, 171);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(63, 20);
            this.comboBox2.TabIndex = 14;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(6, 171);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(59, 12);
            this.label16.TabIndex = 13;
            this.label16.Text = "频道带宽:";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(100, 136);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(62, 21);
            this.textBox3.TabIndex = 12;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 139);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 12);
            this.label15.TabIndex = 11;
            this.label15.Text = "频道数:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 111);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 12);
            this.label14.TabIndex = 10;
            this.label14.Text = "起始频率:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(254, 82);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(23, 12);
            this.label13.TabIndex = 9;
            this.label13.Text = "MHz";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(186, 79);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(62, 21);
            this.textBox2.TabIndex = 8;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(163, 82);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(17, 12);
            this.label12.TabIndex = 7;
            this.label12.Text = "—";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 79);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(59, 12);
            this.label11.TabIndex = 6;
            this.label11.Text = "频率范围:";
            // 
            // chb_125FREBASE
            // 
            this.chb_125FREBASE.AutoSize = true;
            this.chb_125FREBASE.Location = new System.Drawing.Point(169, 51);
            this.chb_125FREBASE.Name = "chb_125FREBASE";
            this.chb_125FREBASE.Size = new System.Drawing.Size(60, 16);
            this.chb_125FREBASE.TabIndex = 5;
            this.chb_125FREBASE.Text = "125KHz";
            this.chb_125FREBASE.UseVisualStyleBackColor = true;
            // 
            // chb_50FREBASE
            // 
            this.chb_50FREBASE.AutoSize = true;
            this.chb_50FREBASE.Location = new System.Drawing.Point(103, 51);
            this.chb_50FREBASE.Name = "chb_50FREBASE";
            this.chb_50FREBASE.Size = new System.Drawing.Size(54, 16);
            this.chb_50FREBASE.TabIndex = 4;
            this.chb_50FREBASE.Text = "50KHz";
            this.chb_50FREBASE.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 51);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 12);
            this.label10.TabIndex = 3;
            this.label10.Text = "频率基数:";
            // 
            // cb_FREMODE
            // 
            this.cb_FREMODE.FormattingEnabled = true;
            this.cb_FREMODE.Items.AddRange(new object[] {
            "中国标准920-925MHz",
            "中国标准840-845MHz",
            "ETSI标准",
            "定频模式915MHz",
            "用户自定义"});
            this.cb_FREMODE.Location = new System.Drawing.Point(103, 15);
            this.cb_FREMODE.Name = "cb_FREMODE";
            this.cb_FREMODE.Size = new System.Drawing.Size(145, 20);
            this.cb_FREMODE.TabIndex = 2;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(103, 79);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(54, 21);
            this.textBox1.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 12);
            this.label9.TabIndex = 0;
            this.label9.Text = "频率基准:";
            // 
            // cb_dbm
            // 
            this.cb_dbm.FormattingEnabled = true;
            this.cb_dbm.Items.AddRange(new object[] {
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30"});
            this.cb_dbm.Location = new System.Drawing.Point(99, 75);
            this.cb_dbm.Name = "cb_dbm";
            this.cb_dbm.Size = new System.Drawing.Size(111, 20);
            this.cb_dbm.TabIndex = 7;
            // 
            // tb_dbm
            // 
            this.tb_dbm.Location = new System.Drawing.Point(99, 46);
            this.tb_dbm.Name = "tb_dbm";
            this.tb_dbm.Size = new System.Drawing.Size(111, 21);
            this.tb_dbm.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(212, 81);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(23, 12);
            this.label8.TabIndex = 5;
            this.label8.Text = "dBm";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(212, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 12);
            this.label7.TabIndex = 4;
            this.label7.Text = "dBm";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 51);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 12);
            this.label6.TabIndex = 3;
            this.label6.Text = "输出功率";
            // 
            // btn_setpower
            // 
            this.btn_setpower.Location = new System.Drawing.Point(262, 74);
            this.btn_setpower.Name = "btn_setpower";
            this.btn_setpower.Size = new System.Drawing.Size(75, 23);
            this.btn_setpower.TabIndex = 2;
            this.btn_setpower.Text = "设置功率";
            this.btn_setpower.UseVisualStyleBackColor = true;
            this.btn_setpower.Click += new System.EventHandler(this.button4_Click);
            // 
            // btn_repower
            // 
            this.btn_repower.Location = new System.Drawing.Point(263, 43);
            this.btn_repower.Name = "btn_repower";
            this.btn_repower.Size = new System.Drawing.Size(75, 23);
            this.btn_repower.TabIndex = 1;
            this.btn_repower.Text = "读取功率";
            this.btn_repower.UseVisualStyleBackColor = true;
            this.btn_repower.Click += new System.EventHandler(this.btn_repower_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(261, 8);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 0;
            this.button3.Text = "版本信息";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // 单步命令
            // 
            this.单步命令.Controls.Add(this.btn_KillTag);
            this.单步命令.Controls.Add(this.txt_KillPsw);
            this.单步命令.Controls.Add(this.label24);
            this.单步命令.Controls.Add(this.btn_lock);
            this.单步命令.Controls.Add(this.btn_lockpara);
            this.单步命令.Controls.Add(this.txt_lockpara);
            this.单步命令.Controls.Add(this.txt_accesspsw);
            this.单步命令.Controls.Add(this.label23);
            this.单步命令.Controls.Add(this.btn_rerasedata);
            this.单步命令.Controls.Add(this.txt_datahex);
            this.单步命令.Controls.Add(this.label22);
            this.单步命令.Controls.Add(this.ritedata);
            this.单步命令.Controls.Add(this.cb_RepeatWrite);
            this.单步命令.Controls.Add(this.txt_datalen);
            this.单步命令.Controls.Add(this.label21);
            this.单步命令.Controls.Add(this.btn_ReadData);
            this.单步命令.Controls.Add(this.cb_ReadRepeat);
            this.单步命令.Controls.Add(this.txt_address);
            this.单步命令.Controls.Add(this.label20);
            this.单步命令.Controls.Add(this.cb_safe);
            this.单步命令.Controls.Add(this.cbx_bank);
            this.单步命令.Controls.Add(this.label19);
            this.单步命令.Controls.Add(this.cB_uii);
            this.单步命令.Controls.Add(this.txt_UII);
            this.单步命令.Controls.Add(this.label18);
            this.单步命令.Location = new System.Drawing.Point(4, 22);
            this.单步命令.Name = "单步命令";
            this.单步命令.Padding = new System.Windows.Forms.Padding(3);
            this.单步命令.Size = new System.Drawing.Size(351, 324);
            this.单步命令.TabIndex = 1;
            this.单步命令.Text = " 单步命令";
            this.单步命令.UseVisualStyleBackColor = true;
            // 
            // btn_KillTag
            // 
            this.btn_KillTag.Location = new System.Drawing.Point(242, 286);
            this.btn_KillTag.Name = "btn_KillTag";
            this.btn_KillTag.Size = new System.Drawing.Size(75, 23);
            this.btn_KillTag.TabIndex = 25;
            this.btn_KillTag.Text = "销毁";
            this.btn_KillTag.UseVisualStyleBackColor = true;
            this.btn_KillTag.Click += new System.EventHandler(this.btn_KillTag_Click);
            // 
            // txt_KillPsw
            // 
            this.txt_KillPsw.Location = new System.Drawing.Point(83, 288);
            this.txt_KillPsw.Name = "txt_KillPsw";
            this.txt_KillPsw.Size = new System.Drawing.Size(153, 21);
            this.txt_KillPsw.TabIndex = 24;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(1, 291);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(95, 12);
            this.label24.TabIndex = 23;
            this.label24.Text = "销毁密码(Hex)：";
            // 
            // btn_lock
            // 
            this.btn_lock.Location = new System.Drawing.Point(242, 252);
            this.btn_lock.Name = "btn_lock";
            this.btn_lock.Size = new System.Drawing.Size(75, 23);
            this.btn_lock.TabIndex = 22;
            this.btn_lock.Text = "锁定";
            this.btn_lock.UseVisualStyleBackColor = true;
            this.btn_lock.Click += new System.EventHandler(this.btn_lock_Click);
            // 
            // btn_lockpara
            // 
            this.btn_lockpara.Location = new System.Drawing.Point(242, 218);
            this.btn_lockpara.Name = "btn_lockpara";
            this.btn_lockpara.Size = new System.Drawing.Size(75, 23);
            this.btn_lockpara.TabIndex = 21;
            this.btn_lockpara.Text = "锁定选项";
            this.btn_lockpara.UseVisualStyleBackColor = true;
            this.btn_lockpara.Click += new System.EventHandler(this.btn_lockpara_Click);
            // 
            // txt_lockpara
            // 
            this.txt_lockpara.Enabled = false;
            this.txt_lockpara.Location = new System.Drawing.Point(96, 220);
            this.txt_lockpara.Name = "txt_lockpara";
            this.txt_lockpara.Size = new System.Drawing.Size(140, 21);
            this.txt_lockpara.TabIndex = 20;
            // 
            // txt_accesspsw
            // 
            this.txt_accesspsw.Location = new System.Drawing.Point(96, 188);
            this.txt_accesspsw.Name = "txt_accesspsw";
            this.txt_accesspsw.Size = new System.Drawing.Size(140, 21);
            this.txt_accesspsw.TabIndex = 19;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(6, 191);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(95, 12);
            this.label23.TabIndex = 18;
            this.label23.Text = "访问密码(Hex)：";
            // 
            // btn_rerasedata
            // 
            this.btn_rerasedata.Location = new System.Drawing.Point(242, 152);
            this.btn_rerasedata.Name = "btn_rerasedata";
            this.btn_rerasedata.Size = new System.Drawing.Size(75, 23);
            this.btn_rerasedata.TabIndex = 17;
            this.btn_rerasedata.Text = "擦除数据";
            this.btn_rerasedata.UseVisualStyleBackColor = true;
            this.btn_rerasedata.Click += new System.EventHandler(this.button5_Click);
            // 
            // txt_datahex
            // 
            this.txt_datahex.Location = new System.Drawing.Point(83, 154);
            this.txt_datahex.Name = "txt_datahex";
            this.txt_datahex.Size = new System.Drawing.Size(153, 21);
            this.txt_datahex.TabIndex = 16;
            this.txt_datahex.TextChanged += new System.EventHandler(this.txt_datahex_TextChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(6, 163);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(71, 12);
            this.label22.TabIndex = 15;
            this.label22.Text = "数据(Hex)：";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // ritedata
            // 
            this.ritedata.BackColor = System.Drawing.Color.Transparent;
            this.ritedata.Location = new System.Drawing.Point(242, 115);
            this.ritedata.Name = "ritedata";
            this.ritedata.Size = new System.Drawing.Size(75, 23);
            this.ritedata.TabIndex = 14;
            this.ritedata.Text = "写入数据";
            this.ritedata.UseVisualStyleBackColor = false;
            this.ritedata.Click += new System.EventHandler(this.ritedata_Click);
            // 
            // cb_RepeatWrite
            // 
            this.cb_RepeatWrite.AutoSize = true;
            this.cb_RepeatWrite.Location = new System.Drawing.Point(188, 122);
            this.cb_RepeatWrite.Name = "cb_RepeatWrite";
            this.cb_RepeatWrite.Size = new System.Drawing.Size(48, 16);
            this.cb_RepeatWrite.TabIndex = 13;
            this.cb_RepeatWrite.Text = "循环";
            this.cb_RepeatWrite.UseVisualStyleBackColor = true;
            // 
            // txt_datalen
            // 
            this.txt_datalen.Location = new System.Drawing.Point(83, 117);
            this.txt_datalen.Name = "txt_datalen";
            this.txt_datalen.Size = new System.Drawing.Size(99, 21);
            this.txt_datalen.TabIndex = 12;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(6, 126);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(41, 12);
            this.label21.TabIndex = 11;
            this.label21.Text = "长度：";
            // 
            // btn_ReadData
            // 
            this.btn_ReadData.Location = new System.Drawing.Point(242, 78);
            this.btn_ReadData.Name = "btn_ReadData";
            this.btn_ReadData.Size = new System.Drawing.Size(75, 23);
            this.btn_ReadData.TabIndex = 10;
            this.btn_ReadData.Text = "读取数据";
            this.btn_ReadData.UseVisualStyleBackColor = true;
            this.btn_ReadData.Click += new System.EventHandler(this.ta_Click);
            // 
            // cb_ReadRepeat
            // 
            this.cb_ReadRepeat.AutoSize = true;
            this.cb_ReadRepeat.Location = new System.Drawing.Point(188, 85);
            this.cb_ReadRepeat.Name = "cb_ReadRepeat";
            this.cb_ReadRepeat.Size = new System.Drawing.Size(48, 16);
            this.cb_ReadRepeat.TabIndex = 9;
            this.cb_ReadRepeat.Text = "循环";
            this.cb_ReadRepeat.UseVisualStyleBackColor = true;
            // 
            // txt_address
            // 
            this.txt_address.Location = new System.Drawing.Point(83, 80);
            this.txt_address.Name = "txt_address";
            this.txt_address.Size = new System.Drawing.Size(99, 21);
            this.txt_address.TabIndex = 8;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(6, 89);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(35, 12);
            this.label20.TabIndex = 7;
            this.label20.Text = "地址:";
            // 
            // cb_safe
            // 
            this.cb_safe.AutoSize = true;
            this.cb_safe.Location = new System.Drawing.Point(250, 45);
            this.cb_safe.Name = "cb_safe";
            this.cb_safe.Size = new System.Drawing.Size(72, 16);
            this.cb_safe.TabIndex = 6;
            this.cb_safe.Text = "安全模式";
            this.cb_safe.UseVisualStyleBackColor = true;
            // 
            // cbx_bank
            // 
            this.cbx_bank.FormattingEnabled = true;
            this.cbx_bank.Items.AddRange(new object[] {
            "00:Reserved",
            "01:UII",
            "10:TID",
            "11:User"});
            this.cbx_bank.Location = new System.Drawing.Point(83, 43);
            this.cbx_bank.Name = "cbx_bank";
            this.cbx_bank.Size = new System.Drawing.Size(153, 20);
            this.cbx_bank.TabIndex = 5;
            this.cbx_bank.SelectedIndexChanged += new System.EventHandler(this.cbx_bank_SelectedIndexChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 51);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(47, 12);
            this.label19.TabIndex = 4;
            this.label19.Text = "数据块:";
            // 
            // cB_uii
            // 
            this.cB_uii.AutoSize = true;
            this.cB_uii.Location = new System.Drawing.Point(250, 13);
            this.cB_uii.Name = "cB_uii";
            this.cB_uii.Size = new System.Drawing.Size(78, 16);
            this.cB_uii.TabIndex = 3;
            this.cB_uii.Text = "不指定UII";
            this.cB_uii.UseVisualStyleBackColor = true;
            this.cB_uii.CheckedChanged += new System.EventHandler(this.cB_uii_CheckedChanged);
            // 
            // txt_UII
            // 
            this.txt_UII.Location = new System.Drawing.Point(83, 8);
            this.txt_UII.Name = "txt_UII";
            this.txt_UII.Size = new System.Drawing.Size(153, 21);
            this.txt_UII.TabIndex = 2;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(6, 17);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(47, 12);
            this.label18.TabIndex = 1;
            this.label18.Text = "标签ID:";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button6);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Location = new System.Drawing.Point(474, 467);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(355, 52);
            this.groupBox3.TabIndex = 33;
            this.groupBox3.TabStop = false;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(20, 19);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 26;
            this.button6.Text = "清除数据";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // FrmUHF
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(845, 527);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.lb_status);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.ctrList);
            this.Controls.Add(this.btn_RtxtClear);
            this.Controls.Add(this.labelSendCount);
            this.Controls.Add(this.checkBoxHexSend);
            this.Controls.Add(this.checkBoxHexView);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txt_Send);
            this.Controls.Add(this.txt_showinfo);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cmbStopBits);
            this.Controls.Add(this.cmbParity);
            this.Controls.Add(this.cmbDataBits);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmUHF";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UHM RFID 实验";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.单步命令.ResumeLayout(false);
            this.单步命令.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbPortName;
        private System.Windows.Forms.ComboBox cmbBaudRate;
        private System.Windows.Forms.ComboBox cmbStopBits;
        private System.Windows.Forms.ComboBox cmbParity;
        private System.Windows.Forms.ComboBox cmbDataBits;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_opencom;
        private System.Windows.Forms.Button btn_closecom;
        private System.Windows.Forms.TextBox txt_showinfo;
        private System.Windows.Forms.TextBox txt_Send;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.CheckBox checkBoxHexView;
        private System.Windows.Forms.CheckBox checkBoxHexSend;
        private System.Windows.Forms.Label labelSendCount;
        private System.Windows.Forms.Button btn_RtxtClear;
        private System.Windows.Forms.ListView ctrList;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Button btn_start;
        private System.Windows.Forms.CheckBox cb_;
        private System.Windows.Forms.ListBox lb_status;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage 单步命令;
        private System.Windows.Forms.Button btn_repower;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btn_setpower;
        private System.Windows.Forms.ComboBox cb_dbm;
        private System.Windows.Forms.TextBox tb_dbm;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.CheckBox chb_125FREBASE;
        private System.Windows.Forms.CheckBox chb_50FREBASE;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cb_FREMODE;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btn_setfreq;
        private System.Windows.Forms.Button btn_readfrq;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.CheckBox cB_uii;
        private System.Windows.Forms.TextBox txt_UII;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.CheckBox cb_safe;
        private System.Windows.Forms.ComboBox cbx_bank;
        private System.Windows.Forms.TextBox txt_address;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.CheckBox cb_ReadRepeat;
        private System.Windows.Forms.Button btn_ReadData;
        private System.Windows.Forms.Button ritedata;
        private System.Windows.Forms.CheckBox cb_RepeatWrite;
        private System.Windows.Forms.TextBox txt_datalen;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button btn_rerasedata;
        private System.Windows.Forms.TextBox txt_datahex;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txt_accesspsw;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txt_lockpara;
        private System.Windows.Forms.Button btn_KillTag;
        private System.Windows.Forms.TextBox txt_KillPsw;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button btn_lock;
        private System.Windows.Forms.Button btn_lockpara;
        private System.Windows.Forms.ComboBox cmb_Qvalue;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Button button6;
    }
}

