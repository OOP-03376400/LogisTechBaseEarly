﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AsynchronousSocket
{
    public delegate void deleAsynSocketProcessMsg(AsynSocketProcessMsg msg);
    public delegate string deleAsynSocketListenerGetContent();

}
