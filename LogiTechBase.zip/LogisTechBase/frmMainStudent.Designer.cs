﻿namespace LogisTechBase
{
    partial class frmMainStudent
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMainStudent));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem系统 = new System.Windows.Forms.ToolStripMenuItem();
            this.系统设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出QToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MI网络通信实验 = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMItem串口通信实验 = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMItem网络通信实验 = new System.Windows.Forms.ToolStripMenuItem();
            this.建立TCPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.建立TCPIP客户端ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MIGPRS应用实验 = new System.Windows.Forms.ToolStripMenuItem();
            this.gPRS实验ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gPS数据分析实验ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gPS数据接收实验RToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.地图操作实验ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MI条码实验 = new System.Windows.Forms.ToolStripMenuItem();
            this.一维条码实验ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.一维条码读取实验ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.一维条形码编码实验ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.条码模块协议分析实验ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.二维条码实验ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.二维条码编码实验ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.二维条码解码实验ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.MIRFID实验 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi1356MHzRFID系统实验 = new System.Windows.Forms.ToolStripMenuItem();
            this.高频RFIDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.高频RFID协议实验ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmi超高频RFID系统的操作实验 = new System.Windows.Forms.ToolStripMenuItem();
            this.标签读取实验ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.通信分析试验ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.超高频RFID系统应用实验ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MIGPS实验 = new System.Windows.Forms.ToolStripMenuItem();
            this.gPS数据分析实验 = new System.Windows.Forms.ToolStripMenuItem();
            this.地图操作实验 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiGPS通讯实验 = new System.Windows.Forms.ToolStripMenuItem();
            this.MIZigbee实验 = new System.Windows.Forms.ToolStripMenuItem();
            this.zigToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.协议分析ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MI综合实验 = new System.Windows.Forms.ToolStripMenuItem();
            this.基于条码技术的仓储管理系统实验BToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.基于超高频RFID的仓储管理系统RToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.基于高频RFID的停车场管理系统HToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.基于物流信息技术的生产物流管理系统PToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gISGPS数据采集与分析管理系统GToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gPSGPRSGIS物流运输监控管理系统ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.仓库环境监测管理系统MToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.学生管理ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.考勤服务端ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.考勤信息统计ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.学生信息管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.标签分发ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.考勤学生端ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.MenuItemAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.关于AToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslbNetState = new System.Windows.Forms.ToolStripStatusLabel();
            this.axShockwaveFlash1 = new AxShockwaveFlashObjects.AxShockwaveFlash();
            this.menuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axShockwaveFlash1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem系统,
            this.MI网络通信实验,
            this.MIGPRS应用实验,
            this.MI条码实验,
            this.MIRFID实验,
            this.MIGPS实验,
            this.MIZigbee实验,
            this.MI综合实验,
            this.学生管理ToolStripMenuItem1,
            this.MenuItemAbout});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(792, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem系统
            // 
            this.toolStripMenuItem系统.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.系统设置ToolStripMenuItem,
            this.退出QToolStripMenuItem});
            this.toolStripMenuItem系统.Name = "toolStripMenuItem系统";
            this.toolStripMenuItem系统.Size = new System.Drawing.Size(58, 21);
            this.toolStripMenuItem系统.Text = "文件(&F)";
            // 
            // 系统设置ToolStripMenuItem
            // 
            this.系统设置ToolStripMenuItem.Name = "系统设置ToolStripMenuItem";
            this.系统设置ToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.系统设置ToolStripMenuItem.Text = "系统设置(&S)";
            this.系统设置ToolStripMenuItem.Click += new System.EventHandler(this.系统设置ToolStripMenuItem_Click);
            // 
            // 退出QToolStripMenuItem
            // 
            this.退出QToolStripMenuItem.Name = "退出QToolStripMenuItem";
            this.退出QToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.退出QToolStripMenuItem.Text = "退出(&Q)";
            this.退出QToolStripMenuItem.Click += new System.EventHandler(this.退出QToolStripMenuItem_Click);
            // 
            // MI网络通信实验
            // 
            this.MI网络通信实验.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSMItem串口通信实验,
            this.TSMItem网络通信实验});
            this.MI网络通信实验.Name = "MI网络通信实验";
            this.MI网络通信实验.Size = new System.Drawing.Size(86, 21);
            this.MI网络通信实验.Text = "网络通信(&N)";
            // 
            // TSMItem串口通信实验
            // 
            this.TSMItem串口通信实验.Name = "TSMItem串口通信实验";
            this.TSMItem串口通信实验.RightToLeftAutoMirrorImage = true;
            this.TSMItem串口通信实验.Size = new System.Drawing.Size(166, 22);
            this.TSMItem串口通信实验.Text = "串口通信实验(&S)";
            this.TSMItem串口通信实验.Click += new System.EventHandler(this.TSMItem串口通信实验_Click);
            // 
            // TSMItem网络通信实验
            // 
            this.TSMItem网络通信实验.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.建立TCPToolStripMenuItem,
            this.建立TCPIP客户端ToolStripMenuItem});
            this.TSMItem网络通信实验.Name = "TSMItem网络通信实验";
            this.TSMItem网络通信实验.Size = new System.Drawing.Size(166, 22);
            this.TSMItem网络通信实验.Text = "网络通信实验(&N)";
            // 
            // 建立TCPToolStripMenuItem
            // 
            this.建立TCPToolStripMenuItem.Name = "建立TCPToolStripMenuItem";
            this.建立TCPToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.建立TCPToolStripMenuItem.Text = "建立TCP/IP服务器(&S)";
            this.建立TCPToolStripMenuItem.Click += new System.EventHandler(this.建立TCPToolStripMenuItem_Click);
            // 
            // 建立TCPIP客户端ToolStripMenuItem
            // 
            this.建立TCPIP客户端ToolStripMenuItem.Name = "建立TCPIP客户端ToolStripMenuItem";
            this.建立TCPIP客户端ToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.建立TCPIP客户端ToolStripMenuItem.Text = "建立TCP/IP客户端(&C)";
            this.建立TCPIP客户端ToolStripMenuItem.Click += new System.EventHandler(this.建立TCPIP客户端ToolStripMenuItem_Click);
            // 
            // MIGPRS应用实验
            // 
            this.MIGPRS应用实验.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gPRS实验ToolStripMenuItem,
            this.gPS数据分析实验ToolStripMenuItem,
            this.gPS数据接收实验RToolStripMenuItem,
            this.地图操作实验ToolStripMenuItem});
            this.MIGPRS应用实验.Name = "MIGPRS应用实验";
            this.MIGPRS应用实验.Size = new System.Drawing.Size(121, 21);
            this.MIGPRS应用实验.Text = "GPS/GPRS/GIS(&G)";
            this.MIGPRS应用实验.Click += new System.EventHandler(this.MIGPRS应用实验_Click);
            // 
            // gPRS实验ToolStripMenuItem
            // 
            this.gPRS实验ToolStripMenuItem.Name = "gPRS实验ToolStripMenuItem";
            this.gPRS实验ToolStripMenuItem.Size = new System.Drawing.Size(251, 22);
            this.gPRS实验ToolStripMenuItem.Text = "GSM/GPRS模块协议分析实验(&P)";
            this.gPRS实验ToolStripMenuItem.Click += new System.EventHandler(this.gPRS实验ToolStripMenuItem_Click);
            // 
            // gPS数据分析实验ToolStripMenuItem
            // 
            this.gPS数据分析实验ToolStripMenuItem.Name = "gPS数据分析实验ToolStripMenuItem";
            this.gPS数据分析实验ToolStripMenuItem.Size = new System.Drawing.Size(251, 22);
            this.gPS数据分析实验ToolStripMenuItem.Text = "GPS 数据分析实验(&S)";
            this.gPS数据分析实验ToolStripMenuItem.Click += new System.EventHandler(this.gPS数据分析实验ToolStripMenuItem_Click_1);
            // 
            // gPS数据接收实验RToolStripMenuItem
            // 
            this.gPS数据接收实验RToolStripMenuItem.Name = "gPS数据接收实验RToolStripMenuItem";
            this.gPS数据接收实验RToolStripMenuItem.Size = new System.Drawing.Size(251, 22);
            this.gPS数据接收实验RToolStripMenuItem.Text = "GPS数据接收实验(&R)";
            this.gPS数据接收实验RToolStripMenuItem.Click += new System.EventHandler(this.gPS数据接收实验RToolStripMenuItem_Click);
            // 
            // 地图操作实验ToolStripMenuItem
            // 
            this.地图操作实验ToolStripMenuItem.Name = "地图操作实验ToolStripMenuItem";
            this.地图操作实验ToolStripMenuItem.Size = new System.Drawing.Size(251, 22);
            this.地图操作实验ToolStripMenuItem.Text = "地图操作实验(&C)";
            this.地图操作实验ToolStripMenuItem.Click += new System.EventHandler(this.地图操作实验ToolStripMenuItem_Click_1);
            // 
            // MI条码实验
            // 
            this.MI条码实验.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.一维条码实验ToolStripMenuItem,
            this.二维条码实验ToolStripMenuItem});
            this.MI条码实验.Name = "MI条码实验";
            this.MI条码实验.Size = new System.Drawing.Size(84, 21);
            this.MI条码实验.Text = "条码实验(&B)";
            // 
            // 一维条码实验ToolStripMenuItem
            // 
            this.一维条码实验ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.一维条码读取实验ToolStripMenuItem,
            this.一维条形码编码实验ToolStripMenuItem,
            this.条码模块协议分析实验ToolStripMenuItem});
            this.一维条码实验ToolStripMenuItem.Name = "一维条码实验ToolStripMenuItem";
            this.一维条码实验ToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.一维条码实验ToolStripMenuItem.Text = "一维条码实验(&D)";
            // 
            // 一维条码读取实验ToolStripMenuItem
            // 
            this.一维条码读取实验ToolStripMenuItem.Name = "一维条码读取实验ToolStripMenuItem";
            this.一维条码读取实验ToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.一维条码读取实验ToolStripMenuItem.Text = "条码读取(&R)";
            this.一维条码读取实验ToolStripMenuItem.Click += new System.EventHandler(this.一维条码读取实验ToolStripMenuItem_Click);
            // 
            // 一维条形码编码实验ToolStripMenuItem
            // 
            this.一维条形码编码实验ToolStripMenuItem.Name = "一维条形码编码实验ToolStripMenuItem";
            this.一维条形码编码实验ToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.一维条形码编码实验ToolStripMenuItem.Text = "条形码编码(&E)";
            this.一维条形码编码实验ToolStripMenuItem.Click += new System.EventHandler(this.一维条形码编码实验ToolStripMenuItem_Click);
            // 
            // 条码模块协议分析实验ToolStripMenuItem
            // 
            this.条码模块协议分析实验ToolStripMenuItem.Name = "条码模块协议分析实验ToolStripMenuItem";
            this.条码模块协议分析实验ToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.条码模块协议分析实验ToolStripMenuItem.Text = "条码模块协议分析(&A)";
            this.条码模块协议分析实验ToolStripMenuItem.Click += new System.EventHandler(this.条码模块协议分析实验ToolStripMenuItem_Click);
            // 
            // 二维条码实验ToolStripMenuItem
            // 
            this.二维条码实验ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.二维条码编码实验ToolStripMenuItem,
            this.二维条码解码实验ToolStripMenuItem1});
            this.二维条码实验ToolStripMenuItem.Name = "二维条码实验ToolStripMenuItem";
            this.二维条码实验ToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.二维条码实验ToolStripMenuItem.Text = "二维条码实验(&T)";
            // 
            // 二维条码编码实验ToolStripMenuItem
            // 
            this.二维条码编码实验ToolStripMenuItem.Name = "二维条码编码实验ToolStripMenuItem";
            this.二维条码编码实验ToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.二维条码编码实验ToolStripMenuItem.Text = "二维条码编码(&E)";
            this.二维条码编码实验ToolStripMenuItem.Click += new System.EventHandler(this.二维条码编码实验ToolStripMenuItem_Click);
            // 
            // 二维条码解码实验ToolStripMenuItem1
            // 
            this.二维条码解码实验ToolStripMenuItem1.Name = "二维条码解码实验ToolStripMenuItem1";
            this.二维条码解码实验ToolStripMenuItem1.Size = new System.Drawing.Size(165, 22);
            this.二维条码解码实验ToolStripMenuItem1.Text = "二维条码解码(&D)";
            this.二维条码解码实验ToolStripMenuItem1.Click += new System.EventHandler(this.二维条码解码实验ToolStripMenuItem1_Click);
            // 
            // MIRFID实验
            // 
            this.MIRFID实验.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmi1356MHzRFID系统实验,
            this.tsmi超高频RFID系统的操作实验});
            this.MIRFID实验.Name = "MIRFID实验";
            this.MIRFID实验.Size = new System.Drawing.Size(87, 21);
            this.MIRFID实验.Text = "RFID实验(&R)";
            // 
            // tsmi1356MHzRFID系统实验
            // 
            this.tsmi1356MHzRFID系统实验.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.高频RFIDToolStripMenuItem,
            this.高频RFID协议实验ToolStripMenuItem});
            this.tsmi1356MHzRFID系统实验.Name = "tsmi1356MHzRFID系统实验";
            this.tsmi1356MHzRFID系统实验.Size = new System.Drawing.Size(208, 22);
            this.tsmi1356MHzRFID系统实验.Text = "高频RFID系统实验(&F)";
            // 
            // 高频RFIDToolStripMenuItem
            // 
            this.高频RFIDToolStripMenuItem.Name = "高频RFIDToolStripMenuItem";
            this.高频RFIDToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.高频RFIDToolStripMenuItem.Text = "标签读取实验(&R)";
            this.高频RFIDToolStripMenuItem.Click += new System.EventHandler(this.高频RFIDToolStripMenuItem_Click);
            // 
            // 高频RFID协议实验ToolStripMenuItem
            // 
            this.高频RFID协议实验ToolStripMenuItem.Name = "高频RFID协议实验ToolStripMenuItem";
            this.高频RFID协议实验ToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.高频RFID协议实验ToolStripMenuItem.Text = "通信协议分析实验(&A)";
            this.高频RFID协议实验ToolStripMenuItem.Click += new System.EventHandler(this.高频RFID协议实验ToolStripMenuItem_Click);
            // 
            // tsmi超高频RFID系统的操作实验
            // 
            this.tsmi超高频RFID系统的操作实验.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.标签读取实验ToolStripMenuItem,
            this.通信分析试验ToolStripMenuItem,
            this.超高频RFID系统应用实验ToolStripMenuItem});
            this.tsmi超高频RFID系统的操作实验.Name = "tsmi超高频RFID系统的操作实验";
            this.tsmi超高频RFID系统的操作实验.Size = new System.Drawing.Size(208, 22);
            this.tsmi超高频RFID系统的操作实验.Text = "超高频 RFID系统实验(&H)";
            this.tsmi超高频RFID系统的操作实验.Click += new System.EventHandler(this.tsmi超高频RFID系统的操作实验_Click);
            // 
            // 标签读取实验ToolStripMenuItem
            // 
            this.标签读取实验ToolStripMenuItem.Name = "标签读取实验ToolStripMenuItem";
            this.标签读取实验ToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.标签读取实验ToolStripMenuItem.Text = "标签读取实验(&R)";
            this.标签读取实验ToolStripMenuItem.Click += new System.EventHandler(this.标签读取实验ToolStripMenuItem_Click);
            // 
            // 通信分析试验ToolStripMenuItem
            // 
            this.通信分析试验ToolStripMenuItem.Name = "通信分析试验ToolStripMenuItem";
            this.通信分析试验ToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.通信分析试验ToolStripMenuItem.Text = "通信协议分析试验(&A)";
            this.通信分析试验ToolStripMenuItem.Click += new System.EventHandler(this.通信分析试验ToolStripMenuItem_Click);
            // 
            // 超高频RFID系统应用实验ToolStripMenuItem
            // 
            this.超高频RFID系统应用实验ToolStripMenuItem.Name = "超高频RFID系统应用实验ToolStripMenuItem";
            this.超高频RFID系统应用实验ToolStripMenuItem.Size = new System.Drawing.Size(211, 22);
            this.超高频RFID系统应用实验ToolStripMenuItem.Text = "超高频RFID系统应用实验";
            this.超高频RFID系统应用实验ToolStripMenuItem.Visible = false;
            // 
            // MIGPS实验
            // 
            this.MIGPS实验.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gPS数据分析实验,
            this.地图操作实验,
            this.tsmiGPS通讯实验});
            this.MIGPS实验.Name = "MIGPS实验";
            this.MIGPS实验.Size = new System.Drawing.Size(92, 21);
            this.MIGPS实验.Text = "GPS/GIS实验";
            this.MIGPS实验.Visible = false;
            // 
            // gPS数据分析实验
            // 
            this.gPS数据分析实验.Name = "gPS数据分析实验";
            this.gPS数据分析实验.Size = new System.Drawing.Size(175, 22);
            this.gPS数据分析实验.Text = "GPS 数据分析实验";
            this.gPS数据分析实验.Click += new System.EventHandler(this.gPS数据分析实验ToolStripMenuItem_Click);
            // 
            // 地图操作实验
            // 
            this.地图操作实验.Name = "地图操作实验";
            this.地图操作实验.Size = new System.Drawing.Size(175, 22);
            this.地图操作实验.Text = "地图操作实验";
            this.地图操作实验.Click += new System.EventHandler(this.地图操作实验ToolStripMenuItem_Click);
            // 
            // tsmiGPS通讯实验
            // 
            this.tsmiGPS通讯实验.Name = "tsmiGPS通讯实验";
            this.tsmiGPS通讯实验.Size = new System.Drawing.Size(175, 22);
            this.tsmiGPS通讯实验.Text = "地图操作实验";
            this.tsmiGPS通讯实验.Click += new System.EventHandler(this.tsmiGPS通讯实验_Click);
            // 
            // MIZigbee实验
            // 
            this.MIZigbee实验.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.zigToolStripMenuItem,
            this.协议分析ToolStripMenuItem});
            this.MIZigbee实验.Name = "MIZigbee实验";
            this.MIZigbee实验.Size = new System.Drawing.Size(99, 21);
            this.MIZigbee实验.Text = "Zigbee实验(&Z)";
            // 
            // zigToolStripMenuItem
            // 
            this.zigToolStripMenuItem.Name = "zigToolStripMenuItem";
            this.zigToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.zigToolStripMenuItem.Text = "Zigbee数据采集(&C)";
            this.zigToolStripMenuItem.Click += new System.EventHandler(this.zigToolStripMenuItem_Click);
            // 
            // 协议分析ToolStripMenuItem
            // 
            this.协议分析ToolStripMenuItem.Name = "协议分析ToolStripMenuItem";
            this.协议分析ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.协议分析ToolStripMenuItem.Text = "Zigbee协议分析(&A)";
            this.协议分析ToolStripMenuItem.Click += new System.EventHandler(this.协议分析ToolStripMenuItem_Click);
            // 
            // MI综合实验
            // 
            this.MI综合实验.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.基于条码技术的仓储管理系统实验BToolStripMenuItem,
            this.基于超高频RFID的仓储管理系统RToolStripMenuItem,
            this.基于高频RFID的停车场管理系统HToolStripMenuItem,
            this.基于物流信息技术的生产物流管理系统PToolStripMenuItem,
            this.gISGPS数据采集与分析管理系统GToolStripMenuItem,
            this.gPSGPRSGIS物流运输监控管理系统ToolStripMenuItem,
            this.仓库环境监测管理系统MToolStripMenuItem});
            this.MI综合实验.Name = "MI综合实验";
            this.MI综合实验.Size = new System.Drawing.Size(83, 21);
            this.MI综合实验.Text = "综合实验(&S)";
            // 
            // 基于条码技术的仓储管理系统实验BToolStripMenuItem
            // 
            this.基于条码技术的仓储管理系统实验BToolStripMenuItem.Name = "基于条码技术的仓储管理系统实验BToolStripMenuItem";
            this.基于条码技术的仓储管理系统实验BToolStripMenuItem.Size = new System.Drawing.Size(295, 22);
            this.基于条码技术的仓储管理系统实验BToolStripMenuItem.Text = "基于条码技术的仓储管理系统实验(&B)";
            this.基于条码技术的仓储管理系统实验BToolStripMenuItem.Click += new System.EventHandler(this.基于条码技术的仓储管理系统实验BToolStripMenuItem_Click);
            // 
            // 基于超高频RFID的仓储管理系统RToolStripMenuItem
            // 
            this.基于超高频RFID的仓储管理系统RToolStripMenuItem.Name = "基于超高频RFID的仓储管理系统RToolStripMenuItem";
            this.基于超高频RFID的仓储管理系统RToolStripMenuItem.Size = new System.Drawing.Size(295, 22);
            this.基于超高频RFID的仓储管理系统RToolStripMenuItem.Text = "基于超高频RFID的仓储管理系统(&R)";
            this.基于超高频RFID的仓储管理系统RToolStripMenuItem.Click += new System.EventHandler(this.基于超高频RFID的仓储管理系统RToolStripMenuItem_Click);
            // 
            // 基于高频RFID的停车场管理系统HToolStripMenuItem
            // 
            this.基于高频RFID的停车场管理系统HToolStripMenuItem.Name = "基于高频RFID的停车场管理系统HToolStripMenuItem";
            this.基于高频RFID的停车场管理系统HToolStripMenuItem.Size = new System.Drawing.Size(295, 22);
            this.基于高频RFID的停车场管理系统HToolStripMenuItem.Text = "基于高频RFID的停车场管理系统(&H)";
            this.基于高频RFID的停车场管理系统HToolStripMenuItem.Click += new System.EventHandler(this.基于高频RFID的停车场管理系统HToolStripMenuItem_Click);
            // 
            // 基于物流信息技术的生产物流管理系统PToolStripMenuItem
            // 
            this.基于物流信息技术的生产物流管理系统PToolStripMenuItem.Name = "基于物流信息技术的生产物流管理系统PToolStripMenuItem";
            this.基于物流信息技术的生产物流管理系统PToolStripMenuItem.Size = new System.Drawing.Size(295, 22);
            this.基于物流信息技术的生产物流管理系统PToolStripMenuItem.Text = "基于物流信息技术的生产物流管理系统(&P)";
            this.基于物流信息技术的生产物流管理系统PToolStripMenuItem.Click += new System.EventHandler(this.基于物流信息技术的生产物流管理系统PToolStripMenuItem_Click);
            // 
            // gISGPS数据采集与分析管理系统GToolStripMenuItem
            // 
            this.gISGPS数据采集与分析管理系统GToolStripMenuItem.Name = "gISGPS数据采集与分析管理系统GToolStripMenuItem";
            this.gISGPS数据采集与分析管理系统GToolStripMenuItem.Size = new System.Drawing.Size(295, 22);
            this.gISGPS数据采集与分析管理系统GToolStripMenuItem.Text = "GIS/GPS数据采集与分析管理系统(&G)";
            this.gISGPS数据采集与分析管理系统GToolStripMenuItem.Click += new System.EventHandler(this.gISGPS数据采集与分析管理系统GToolStripMenuItem_Click);
            // 
            // gPSGPRSGIS物流运输监控管理系统ToolStripMenuItem
            // 
            this.gPSGPRSGIS物流运输监控管理系统ToolStripMenuItem.Name = "gPSGPRSGIS物流运输监控管理系统ToolStripMenuItem";
            this.gPSGPRSGIS物流运输监控管理系统ToolStripMenuItem.Size = new System.Drawing.Size(295, 22);
            this.gPSGPRSGIS物流运输监控管理系统ToolStripMenuItem.Text = "GPS/GPRS/GIS物流运输监控管理系统";
            this.gPSGPRSGIS物流运输监控管理系统ToolStripMenuItem.Click += new System.EventHandler(this.gPSGPRSGIS物流运输监控管理系统ToolStripMenuItem_Click);
            // 
            // 仓库环境监测管理系统MToolStripMenuItem
            // 
            this.仓库环境监测管理系统MToolStripMenuItem.Name = "仓库环境监测管理系统MToolStripMenuItem";
            this.仓库环境监测管理系统MToolStripMenuItem.Size = new System.Drawing.Size(295, 22);
            this.仓库环境监测管理系统MToolStripMenuItem.Text = "仓库环境监测管理系统(&M)";
            this.仓库环境监测管理系统MToolStripMenuItem.Click += new System.EventHandler(this.仓库环境监测管理系统MToolStripMenuItem_Click);
            // 
            // 学生管理ToolStripMenuItem1
            // 
            this.学生管理ToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.考勤服务端ToolStripMenuItem,
            this.考勤信息统计ToolStripMenuItem,
            this.学生信息管理ToolStripMenuItem,
            this.标签分发ToolStripMenuItem1,
            this.考勤学生端ToolStripMenuItem1});
            this.学生管理ToolStripMenuItem1.Name = "学生管理ToolStripMenuItem1";
            this.学生管理ToolStripMenuItem1.Size = new System.Drawing.Size(60, 21);
            this.学生管理ToolStripMenuItem1.Text = "考勤(&C)";
            // 
            // 考勤服务端ToolStripMenuItem
            // 
            this.考勤服务端ToolStripMenuItem.Name = "考勤服务端ToolStripMenuItem";
            this.考勤服务端ToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.考勤服务端ToolStripMenuItem.Text = "启动考勤(&S)";
            this.考勤服务端ToolStripMenuItem.Visible = false;
            this.考勤服务端ToolStripMenuItem.Click += new System.EventHandler(this.考勤服务端ToolStripMenuItem_Click);
            // 
            // 考勤信息统计ToolStripMenuItem
            // 
            this.考勤信息统计ToolStripMenuItem.Name = "考勤信息统计ToolStripMenuItem";
            this.考勤信息统计ToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.考勤信息统计ToolStripMenuItem.Text = "考勤信息统计(&A)";
            this.考勤信息统计ToolStripMenuItem.Visible = false;
            this.考勤信息统计ToolStripMenuItem.Click += new System.EventHandler(this.考勤信息统计ToolStripMenuItem_Click);
            // 
            // 学生信息管理ToolStripMenuItem
            // 
            this.学生信息管理ToolStripMenuItem.Name = "学生信息管理ToolStripMenuItem";
            this.学生信息管理ToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.学生信息管理ToolStripMenuItem.Text = "学生信息管理(&N)";
            this.学生信息管理ToolStripMenuItem.Visible = false;
            this.学生信息管理ToolStripMenuItem.Click += new System.EventHandler(this.学生信息管理ToolStripMenuItem_Click);
            // 
            // 标签分发ToolStripMenuItem1
            // 
            this.标签分发ToolStripMenuItem1.Name = "标签分发ToolStripMenuItem1";
            this.标签分发ToolStripMenuItem1.Size = new System.Drawing.Size(166, 22);
            this.标签分发ToolStripMenuItem1.Text = "学生卡分发(&M)";
            this.标签分发ToolStripMenuItem1.Visible = false;
            this.标签分发ToolStripMenuItem1.Click += new System.EventHandler(this.标签分发ToolStripMenuItem_Click);
            // 
            // 考勤学生端ToolStripMenuItem1
            // 
            this.考勤学生端ToolStripMenuItem1.Name = "考勤学生端ToolStripMenuItem1";
            this.考勤学生端ToolStripMenuItem1.Size = new System.Drawing.Size(166, 22);
            this.考勤学生端ToolStripMenuItem1.Text = "启动考勤(&C)";
            this.考勤学生端ToolStripMenuItem1.Click += new System.EventHandler(this.考勤学生端ToolStripMenuItem_Click);
            // 
            // MenuItemAbout
            // 
            this.MenuItemAbout.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.关于AToolStripMenuItem});
            this.MenuItemAbout.Name = "MenuItemAbout";
            this.MenuItemAbout.Size = new System.Drawing.Size(61, 21);
            this.MenuItemAbout.Text = "帮助(&H)";
            // 
            // 关于AToolStripMenuItem
            // 
            this.关于AToolStripMenuItem.Name = "关于AToolStripMenuItem";
            this.关于AToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.关于AToolStripMenuItem.Text = "关于(&A)";
            this.关于AToolStripMenuItem.Click += new System.EventHandler(this.关于AToolStripMenuItem_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.tsslbNetState});
            this.statusStrip1.Location = new System.Drawing.Point(0, 544);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(792, 22);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            this.statusStrip1.Visible = false;
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(92, 17);
            this.toolStripStatusLabel1.Text = "网络连接状态：";
            // 
            // tsslbNetState
            // 
            this.tsslbNetState.Name = "tsslbNetState";
            this.tsslbNetState.Size = new System.Drawing.Size(32, 17);
            this.tsslbNetState.Text = "正常";
            // 
            // axShockwaveFlash1
            // 
            this.axShockwaveFlash1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.axShockwaveFlash1.Enabled = true;
            this.axShockwaveFlash1.Location = new System.Drawing.Point(0, 25);
            this.axShockwaveFlash1.Name = "axShockwaveFlash1";
            this.axShockwaveFlash1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axShockwaveFlash1.OcxState")));
            this.axShockwaveFlash1.Size = new System.Drawing.Size(792, 541);
            this.axShockwaveFlash1.TabIndex = 4;
            // 
            // frmMainStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 566);
            this.Controls.Add(this.axShockwaveFlash1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmMainStudent";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "物流信息技术与信息管理(学生端)";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.axShockwaveFlash1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MI网络通信实验;
        private System.Windows.Forms.ToolStripMenuItem MIGPRS应用实验;
        private System.Windows.Forms.ToolStripMenuItem TSMItem串口通信实验;
        private System.Windows.Forms.ToolStripMenuItem TSMItem网络通信实验;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripMenuItem MI条码实验;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel tsslbNetState;
        private System.Windows.Forms.ToolStripMenuItem MIRFID实验;
        private System.Windows.Forms.ToolStripMenuItem tsmi1356MHzRFID系统实验;
        private System.Windows.Forms.ToolStripMenuItem tsmi超高频RFID系统的操作实验;
        private System.Windows.Forms.ToolStripMenuItem 标签读取实验ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 通信分析试验ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 超高频RFID系统应用实验ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 建立TCPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 建立TCPIP客户端ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 学生管理ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 学生信息管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 标签分发ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 考勤服务端ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 考勤学生端ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 考勤信息统计ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MIZigbee实验;
        private System.Windows.Forms.ToolStripMenuItem zigToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 协议分析ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MIGPS实验;
        private System.Windows.Forms.ToolStripMenuItem gPS数据分析实验;
        private System.Windows.Forms.ToolStripMenuItem 地图操作实验;
        private System.Windows.Forms.ToolStripMenuItem tsmiGPS通讯实验;
        private System.Windows.Forms.ToolStripMenuItem gPRS实验ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 高频RFID协议实验ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 高频RFIDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 一维条码实验ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 一维条形码编码实验ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 条码模块协议分析实验ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 一维条码读取实验ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 二维条码实验ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 二维条码编码实验ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 二维条码解码实验ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem gPS数据分析实验ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 地图操作实验ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MenuItemAbout;
        private System.Windows.Forms.ToolStripMenuItem 关于AToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem系统;
        private System.Windows.Forms.ToolStripMenuItem 系统设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出QToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gPS数据接收实验RToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem MI综合实验;
        private AxShockwaveFlashObjects.AxShockwaveFlash axShockwaveFlash1;
        private System.Windows.Forms.ToolStripMenuItem 基于条码技术的仓储管理系统实验BToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 基于超高频RFID的仓储管理系统RToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 基于高频RFID的停车场管理系统HToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 基于物流信息技术的生产物流管理系统PToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gISGPS数据采集与分析管理系统GToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gPSGPRSGIS物流运输监控管理系统ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 仓库环境监测管理系统MToolStripMenuItem;
    }
}

